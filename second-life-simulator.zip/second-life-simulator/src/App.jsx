
import React, { useMemo, useState } from "react";

/*
  SECOND LIFE — Full functional prototype
  ---------------------------------------
  Architecture:
  Death -> Goddess -> Prayer/Gacha -> World -> 75Q Assessment -> 25Q Secondary
  -> Goals -> Character Sheet -> Lobby -> Life Simulation / Life History -> Ending

  This is psychologically inspired game logic, NOT a validated psychological,
  IQ, MBTI, or clinical test.
*/

const TRAITS = [
  "INT","LOG","ADP","CRE","PER","RISK","IMP","RES","IND","CON",
  "SOC","CHA","DOM","TRU","HON","LOY","JUST","COMP","UTIL","SELF","AMB"
];

const TRAIT_LABEL = {
  INT:"Intelligence", LOG:"Logic", ADP:"Adaptability", CRE:"Creativity",
  PER:"Perception", RISK:"Risk tolerance", IMP:"Impulsivity", RES:"Resilience",
  IND:"Independence", CON:"Discipline", SOC:"Social awareness", CHA:"Charisma",
  DOM:"Dominance", TRU:"Trust tendency", HON:"Honor", LOY:"Loyalty",
  JUST:"Justice", COMP:"Compassion", UTIL:"Pragmatism", SELF:"Self-preservation",
  AMB:"Ambition"
};

const clamp = (n,a=0,b=100)=>Math.max(a,Math.min(b,Math.round(n)));
const pick = arr => arr[Math.floor(Math.random()*arr.length)];
const uid = () => Math.random().toString(36).slice(2,9);

const GENDERS = [
  "Male","Female","Non-binary","Androgynous","Genderfluid","Agender","Other"
];

const WORLDS = [
  {id:"kingdom",name:"Kingdom Fantasy",tag:"Politics • Magic • War",desc:"Kingdoms, guilds, monsters, noble houses and ancient magic.",systems:["Mana","Swordsmanship","Guilds","Nobility"]},
  {id:"dark",name:"Dark Fantasy",tag:"Curse • Survival • Fate",desc:"A cruel world where curses, monsters and institutions shape survival.",systems:["Mana","Curses","Relics","Prophecy"]},
  {id:"high",name:"High Fantasy",tag:"Epic • Ancient • Mythic",desc:"Powerful civilizations, legendary races and world-scale conflicts.",systems:["Mana","Divine Power","Artifacts","Ancient Races"]},
  {id:"magitech",name:"Magitech",tag:"Magic • Machines",desc:"Magic and engineering developed together into a technological civilization.",systems:["Mana","Engineering","Artifacts","Industry"]},
  {id:"wildwest",name:"Wild West",tag:"Frontier • Guns • Freedom",desc:"Dust towns, railroads, lawmen, outlaws and frontier settlements.",systems:["Firearms","Horsemanship","Economy","Reputation"]},
  {id:"murim",name:"Murim",tag:"Qi • Sects • Jianghu",desc:"Martial sects, wandering masters, internal energy and rival clans.",systems:["Qi","Meridians","Martial Arts","Sect Reputation"]},
  {id:"apocalypse",name:"Apocalypse",tag:"Scarcity • Survival",desc:"Civilization collapsed. There is no mana; knowledge and resources matter.",systems:["Scavenging","Technology","Medicine","Shelters"]},
  {id:"academia",name:"Academia",tag:"Study • Rivalry • Discovery",desc:"Schools, laboratories, libraries and competitive research define society.",systems:["Research","Magic","Technology","Academics"]},
  {id:"pirate",name:"Pirate Seas",tag:"Ships • Trade • Exploration",desc:"Island nations, fleets, sea monsters, merchants and pirates.",systems:["Navigation","Sailing","Trade","Combat"]},
  {id:"horror",name:"Horror Mystery",tag:"Secrets • Investigation",desc:"The world looks ordinary until hidden rules begin to surface.",systems:["Investigation","Occult","Psychology","Survival"]},
  {id:"industrial",name:"Industrial Fantasy",tag:"Factories • Class • Revolution",desc:"Steam, industry, labor movements and magic-powered machinery.",systems:["Industry","Engineering","Politics","Alchemy"]},
  {id:"advanced",name:"Advanced Civilization",tag:"Science • Cities • AI",desc:"A highly developed civilization with advanced infrastructure and science.",systems:["Science","AI","Cybernetics","Politics"]},
];

const WEAPONS = [
  ["sword","Sword","Balanced melee weapon"],["greatsword","Greatsword","Heavy two-handed blade"],
  ["rapier","Rapier","Precision dueling blade"],["spear","Spear","Reach and control"],
  ["halberd","Halberd","Polearm with multiple attack options"],["axe","Axe","Powerful close-range weapon"],
  ["mace","Mace","Armor-breaking blunt weapon"],["hammer","War Hammer","Heavy impact weapon"],
  ["dagger","Dagger","Compact precision weapon"],["bow","Bow","Long-range projectile weapon"],
  ["crossbow","Crossbow","Mechanical ranged weapon"],["staff","Staff","Focus for magic or martial techniques"],
  ["tome","Tome","Knowledge-based casting focus"],["shield","Shield","Defense and formation fighting"],
  ["fists","Fists","Unarmed combat"],["claws","Claws","Natural or artificial close combat"],
  ["whip","Whip","Flexible control weapon"],["scythe","Scythe","Unorthodox sweeping weapon"],
  ["gun","Firearm","Modern ranged weapon"],["revolver","Revolver","Frontier sidearm"],
  ["rifle","Rifle","Long-range firearm"],["improvised","Improvised","Whatever the environment provides"],
  ["artifact","Artifact","Rare supernatural weapon"],["qi_blade","Qi Blade","Murim weapon shaped by internal energy"]
].map(([id,name,desc])=>({id,name,desc}));

const ROLE_SEEDS = [
  "Fighter","Warrior","Swordsman","Spearman","Axeman","Brawler","Boxer","Monk","Guardian","Knight",
  "Heavy Knight","Cavalier","Duelist","Gladiator","Berserker","Battle Master","Weapon Master",
  "Rogue","Thief","Assassin","Shadow Assassin","Ninja","Scout","Spy","Infiltrator","Bounty Hunter",
  "Tracker","Poisoner","Trickster","Outlaw","Archer","Ranger","Sniper","Crossbowman","Hunter",
  "Gunslinger","Sharpshooter","Artilleryman","Mage","Elementalist","Fire Mage","Ice Mage","Water Mage",
  "Wind Mage","Earth Mage","Lightning Mage","Dark Mage","Light Mage","Void Mage","Blood Mage","Battle Mage",
  "Archmage","Healer","Priest","Saint","Battle Priest","Inquisitor","Cleric","Medic","Physician",
  "Herbalist","Plague Doctor","Alchemist","Apothecary","Blacksmith","Armorer","Crafter","Runesmith",
  "Jeweler","Artisan","Engineer","Mechanic","Inventor","Technician","Scientist","Researcher","Chemist",
  "Weapons Engineer","Programmer","Scholar","Strategist","Tactician","Historian","Philosopher","Investigator",
  "Detective","Psychic","Mentalist","Oracle","Leader","Commander","General","Noble","Politician","Diplomat",
  "Merchant","Guildmaster","King","Emperor","Survivor","Scavenger","Wasteland Survivor","Nomad","Explorer",
  "Adventurer","Fisherman","Farmer","Miner","Forager","Drifter","Cowboy","Sheriff","Prospector","Rancher",
  "Frontier Doctor","Martial Artist","Internal Cultivator","External Fighter","Qi Master","Sword Disciple",
  "Spear Disciple","Demonic Cultivator","Sect Disciple","Martial Doctor","Wandering Martial Artist",
  "Dark Warrior","Cursed Fighter","Heretic","Forbidden Mage","Necromancer","Demon Knight","Blood Knight",
  "Soul Eater","Plaguebringer","Abyss Walker","Diplomatic Envoy","Cartographer","Beast Tamer","Architect",
  "Librarian","Courier","Chef","Farmer-Merchant","Street Doctor","Relic Hunter","Monster Scholar","Mediator",
  "Spy Master","Ship Captain","Navigator","Pirate","Quartermaster","Airship Pilot","Runeblade","Battle Engineer",
  "Warden","Beast Hunter","Monster Slayer","Arena Champion","Bodyguard","Court Mage","Royal Physician"
];
const ROLES = [...new Set(ROLE_SEEDS)].map((name,i)=>({id:"role_"+i,name,tier:i<35?"Lower":i<80?"Middle":i<125?"Upper":i<150?"Top":"Transcendent"}));

const CHAT_TEMPLATES = [
  "You notice {name} checking the door before speaking.",
  "{name} asks what you actually want from this new life.",
  "A quiet joke from {name} breaks the tension.",
  "{name} disagrees with your plan but stays to help.",
  "You and {name} compare what you remember from before.",
  "{name} notices your mood before you say anything.",
  "A small argument reveals a difference in values.",
  "{name} offers a practical solution instead of comfort.",
  "You discover a habit {name} has kept secret.",
  "{name} asks whether you trust them.",
  "The two of you make plans for the next season.",
  "{name} admits they are afraid of failing the group.",
  "A shared meal becomes an unexpectedly important memory.",
  "{name} challenges your assumption about the world.",
  "You realize your relationship has changed.",
  "{name} remembers a promise you almost forgot.",
  "You and {name} disagree about whether mercy is wise.",
  "{name} quietly covers for your mistake.",
  "You both laugh at how badly the plan went.",
  "{name} asks what kind of person you want to become.",
  "A stranger mistakes you for rivals.",
  "{name} proposes a risky shortcut.",
  "You teach {name} something; they teach you something back.",
  "{name} becomes unusually quiet after hearing the news.",
  "The conversation turns toward family.",
  "{name} asks what you would do with unlimited freedom.",
  "You notice {name} has become more confident.",
  "{name} warns you that ambition has a cost.",
  "A small favor strengthens the bond between you.",
  "{name} says they would rather hear the truth.",
  "You discover you both dislike the same local custom.",
  "{name} asks whether the past should matter.",
  "You catch {name} planning three steps ahead.",
  "{name} gives you advice you did not ask for.",
  "A disagreement ends with mutual respect.",
  "{name} tells you about a goal they have never said aloud.",
  "You both watch the settlement change around you.",
  "{name} refuses to let you carry everything alone.",
  "You discuss whether strength means power or endurance.",
  "{name} notices a change in your fighting style.",
  "You and {name} make a pact for the next crisis.",
  "{name} asks you to judge a difficult decision.",
  "A rumor about you reaches {name}.",
  "{name} reacts badly to being underestimated.",
  "You realize a former enemy may become an ally.",
  "{name} remembers your first meeting differently.",
  "A celebration reveals how much the group has changed.",
  "{name} asks whether you would choose family or ambition.",
  "You discuss what makes a life meaningful.",
  "{name} suggests leaving everything behind.",
  "You decide to stay.",
  "{name} asks for your honest opinion.",
  "A silence between you feels comfortable rather than awkward.",
  "{name} admits they were wrong.",
  "You admit that you were wrong.",
  "{name} asks what you fear losing.",
  "You talk about the future without knowing whether it will happen.",
  "{name} brings you an item they thought you would appreciate.",
  "You notice {name} protecting someone weaker.",
  "{name} asks whether you believe in fate.",
  "You explain why you chose this path.",
  "{name} challenges you to prove your conviction.",
  "The group debates whether to accept a dangerous contract.",
  "{name} votes against you.",
  "{name} unexpectedly supports you.",
  "A local child asks why you carry a weapon.",
  "{name} tells a story from their homeland.",
  "You teach each other a phrase from different cultures.",
  "{name} misunderstands your intention.",
  "The misunderstanding is resolved.",
  "{name} starts calling you by a nickname.",
  "You realize the nickname stuck.",
  "{name} asks what your ideal home would look like.",
  "You discuss money, work and the cost of freedom.",
  "{name} wants to build something lasting.",
  "You discuss whether people can really change.",
  "{name} says they changed because of you.",
  "You are unsure whether that is a compliment.",
  "{name} asks for one promise.",
  "You make the promise.",
  "{name} asks if you regret anything.",
  "You answer honestly.",
  "{name} refuses to answer the same question.",
  "You let the subject go.",
  "{name} notices you are exhausted.",
  "The group changes its route because of your warning.",
  "{name} says your instincts have improved.",
  "You ask {name} where they see themselves in ten years.",
  "{name} laughs at the idea of planning ten years ahead.",
  "You find an old letter and discuss what it means.",
  "{name} asks whether power should belong to everyone.",
  "The argument becomes unexpectedly philosophical.",
  "{name} prefers action to debate.",
  "You decide to gather more information first.",
  "{name} respects the decision.",
  "A festival creates a rare peaceful evening.",
  "{name} teaches you a local game.",
  "You lose badly.",
  "{name} pretends not to celebrate.",
  "You both know they are celebrating.",
  "{name} becomes protective after hearing a rumor.",
  "You reassure them.",
  "{name} asks whether you still trust them.",
  "You answer without hesitation.",
  "{name} seems surprised.",
  "You notice how much time has passed.",
  "{name} asks whether this world feels like home.",
  "You cannot answer immediately.",
  "{name} says home might be something people build.",
  "You remember the first day you arrived.",
  "{name} asks what you would tell your younger self.",
  "The answer changes the way you see the present.",
  "{name} asks whether you are happy.",
  "You give a complicated answer.",
  "{name} accepts it.",
  "You discuss the difference between surviving and living.",
  "{name} says both matter.",
  "A difficult choice approaches.",
  "You ask {name} what they would do.",
  "{name} asks what you would do.",
  "Neither of you has a perfect answer.",
  "You choose together.",
  "{name} stays beside you afterward.",
  "The crisis passes, but the relationship is different.",
  "{name} says they are proud of you.",
  "You realize you rarely hear that.",
  "{name} asks you to rest.",
  "You promise to try.",
  "{name} reminds you that promises need action.",
  "You laugh.",
  "{name} laughs too.",
  "The ordinary moment becomes one of your favorite memories.",
  "{name} asks whether you would do it all again.",
  "You say you do not know.",
  "{name} says that is enough.",
  "You both look toward the road ahead.",
  "{name} says the next chapter will be different.",
  "You agree.",
  "The conversation ends, but the memory remains."
];
const CHAT_VARIATIONS = Array.from({length:175},(_,i)=>({
  id:"chat_"+(i+1),
  text:CHAT_TEMPLATES[i%CHAT_TEMPLATES.length],
  tone:["warm","tense","funny","serious","reflective"][i%5],
  trait:TRAITS[i%TRAITS.length]
}));

const MAJOR_EVENTS = [
  "A war begins between major factions.","A plague changes the settlement.","A legendary artifact is discovered.",
  "Your mentor offers a final lesson.","A trusted ally betrays the group.","A rival challenges your reputation.",
  "A city falls into political chaos.","You are offered a powerful position.","A prophecy names you unexpectedly.",
  "A monster migration reaches civilization.","Your family needs help.","A guild offers you membership.",
  "You discover a hidden organization.","A border closes because of conflict.","A major festival changes your social circle.",
  "A research breakthrough changes your career.","A ship is lost at sea.","A rebellion begins.",
  "A kingdom asks for your service.","A dangerous curse spreads.","A child in your community needs protection.",
  "A former enemy requests peace.","Your master disappears.","An old secret about your origin surfaces.",
  "You must choose between two major objectives."
].map((name,i)=>({id:"major_"+i+1,name,weight:1}));

const SECONDARY_EVENTS = [
  "A merchant offers a strange bargain.","You repair something for a neighbor.","A rumor reaches you.",
  "You find a useful book.","A local tournament is announced.","Your companion needs advice.",
  "You receive an unexpected letter.","A minor injury changes your schedule.","A new shop opens.",
  "You meet someone from another culture.","A small debt becomes complicated.","A local official asks a favor.",
  "You discover a shortcut.","You lose an item and must search for it.","A teacher notices your talent.",
  "A stranger recognizes your weapon.","You are invited to a private gathering.","A storm changes your plans.",
  "A tool breaks at the worst time.","You help settle a disagreement.","A local tradition surprises you.",
  "A contract seems too good to be true.","A friend asks for honest feedback.","A new apprentice joins your circle.",
  "You hear a song from your old world."
].map((name,i)=>({id:"secondary_"+(i+1),name,weight:1}));

const QUESTIONS = [
  ["A settlement is attacked while you can escape alone. Your friend is still inside.","Go back immediately","Find another route in","Leave and send help later","Wait for more information",["RISK","LOY"],[4,3]],
  ["You discover a rule is unfair but breaking it could hurt innocent people.","Break it openly","Work around it","Obey for now","Organize others to change it",["JUST","HON"],[4,3]],
  ["A stranger offers knowledge that could make you powerful, but their motives are unclear.","Accept","Investigate first","Refuse","Trade something of equal value",["INT","TRU"],[3,3]],
  ["Your plan fails because the environment changed.","Repeat the plan","Adapt quickly","Ask someone else","Abandon the goal",["ADP","RES"],[5,3]],
  ["A teammate makes a serious mistake.","Blame them","Fix the problem first","Teach them","Replace them",["COMP","CON"],[4,3]],
  ["You have one month to master a difficult skill.","Practice daily","Find a better teacher","Experiment constantly","Focus on a different skill",["CON","CRE"],[4,4]],
  ["A powerful person insults you publicly.","Challenge them","Ignore it","Answer calmly","Plan a later response",["DOM","RES"],[4,3]],
  ["A risky opportunity could change your life.","Take it","Research it","Ask a friend","Decline",["RISK","INT"],[5,3]],
  ["You have enough resources for either yourself or your whole group.","Keep most","Split evenly","Give to those in greatest need","Invest it for later",["COMP","UTIL"],[5,3]],
  ["You learn your closest ally hid an important fact.","Confront them","Wait for context","Forgive immediately","Distance yourself",["TRU","PER"],[4,4]],
  ["A rival is better than you at something important.","Train harder","Study their method","Cooperate","Find a different specialty",["AMB","ADP"],[4,3]],
  ["You can win a conflict by using a technicality.","Use it","Refuse","Use it but disclose it","Ask for a fairer solution",["UTIL","HON"],[4,3]],
  ["You enter an unfamiliar city.","Explore","Find an expert","Stay near safety","Blend into the crowd",["ADP","PER"],[4,3]],
  ["Your leader makes a decision you believe is wrong.","Follow","Speak privately","Challenge publicly","Leave",["HON","DOM"],[4,3]],
  ["Someone weaker asks you to teach them.","Teach","Decline","Teach only basics","Ask what they need first",["COMP","SOC"],[4,3]],
  ["A valuable object may be cursed.","Touch it","Study it","Sell it","Leave it",["CRE","PER"],[4,4]],
  ["Your friend wants revenge after being wronged.","Support them","Stop them","Help them confront safely","Stay out",["LOY","JUST"],[4,4]],
  ["You are offered authority over people.","Accept","Decline","Accept with limits","Ask for shared leadership",["DOM","SOC"],[4,3]],
  ["You fail publicly.","Hide it","Learn from it","Blame circumstances","Try again immediately",["RES","HON"],[5,2]],
  ["A peaceful solution takes longer but avoids collateral harm.","Choose peace","Choose speed","Gather more information","Let both sides decide",["COMP","UTIL"],[5,3]],
  ["You find evidence that your worldview may be wrong.","Reject it","Investigate","Accept immediately","Keep it private",["INT","ADP"],[5,3]],
  ["A friend asks whether you trust them.","Yes","Not yet","Trust them with limits","Ask why",["TRU","PER"],[4,3]],
  ["You must choose between freedom and security.","Freedom","Security","A balance","Depends on the situation",["IND","SELF"],[5,4]],
  ["You are exhausted but someone depends on you.","Push through","Ask for help","Delegate","Rest and return",["RES","COMP"],[4,3]],
  ["A mentor criticizes your technique.","Defend it","Listen","Test both methods","Leave the mentor",["CON","ADP"],[4,4]],
  ["A mystery has no obvious reward.","Investigate","Ignore","Ask others","Wait",["PER","INT"],[4,3]],
  ["A wealthy patron wants control over your work.","Accept","Refuse","Negotiate","Find another patron",["IND","UTIL"],[5,3]],
  ["You can become famous by exaggerating your achievements.","Do it","Stay honest","Say nothing","Let others speak",["CHA","HON"],[4,4]],
  ["A dangerous road is the fastest route.","Take it","Avoid it","Scout it","Travel with a group",["RISK","PER"],[4,4]],
  ["Your group cannot agree.","Vote","Lead","Compromise","Let the strongest decide",["SOC","DOM"],[4,3]],
  ["You discover your talent is unusual in this world.","Hide it","Develop it","Find experts","Use it publicly",["IND","CRE"],[4,4]],
  ["A stranger asks for shelter.","Allow them","Refuse","Verify first","Offer limited shelter",["COMP","TRU"],[4,3]],
  ["A law protects the powerful more than the weak.","Obey","Challenge it","Work around it","Gather evidence",["JUST","PER"],[5,4]],
  ["You have to choose a weapon without knowing the future.","Choose familiar","Choose versatile","Choose powerful","Choose unusual",["ADP","RISK"],[4,3]],
  ["A friend becomes distant after success.","Confront","Give space","Support quietly","Move on",["SOC","RES"],[4,3]],
  ["You learn someone has been spreading rumors about you.","Confront","Ignore","Correct the record","Investigate why",["CHA","PER"],[4,4]],
  ["Two factions want your loyalty.","Choose values","Choose winner","Stay neutral","Broker peace",["HON","UTIL"],[4,5]],
  ["Your companion reveals a hidden fear.","Talk gently","Pretend not to hear","Ask later","Respect privacy",["COMP","SOC"],[6,3]],
  ["You are finally strong enough to pursue old revenge.","Do it","Let it go","Confront without harm","Do nothing",["DOM","RES"],[4,5]],
  ["What matters most if this life ended tomorrow?","Protect others","Live honestly","Be understood","Understand the world",["LOY","HON"],[4,4]],
  ["The Goddess asks whether you are ready.","Yes","Yes, despite doubt","Not ready, but go","I want to discover",["CON","ADP"],[3,3]],
  ["A town asks you to solve a dispute you do not understand.","Take charge","Listen to both sides","Decline","Investigate first",["SOC","PER"],[4,4]],
  ["You can learn from an enemy.","Never","If useful","If they show sincerity","Study them secretly",["ADP","UTIL"],[4,4]],
  ["Your best opportunity requires leaving home.","Leave","Stay","Visit first","Bring people with you",["AMB","IND"],[4,3]],
  ["You see a powerful person abusing their status.","Intervene","Get authorities","Gather allies","Avoid the danger",["JUST","RISK"],[5,4]],
  ["A complex machine fails just before an important deadline.","Repair it","Replace it","Simplify the task","Ask an expert",["CRE","LOG"],[5,4]],
  ["You have three competing goals.","Pick one","Pursue all slowly","Ask others","Prioritize by values",["AMB","CON"],[4,4]],
  ["Your companion is making reckless decisions.","Stop them","Warn them","Join them","Set a boundary",["LOY","SELF"],[4,4]],
  ["You are offered a shortcut that feels morally questionable.","Take it","Refuse","Investigate consequences","Negotiate an alternative",["UTIL","HON"],[4,4]],
  ["A community needs a leader but nobody volunteers.","Volunteer","Nominate someone","Stay neutral","Build a council",["DOM","SOC"],[5,4]],
  ["You find a lost child in a dangerous area.","Carry them","Find their family","Call for help","Secure the area first",["COMP","PER"],[5,3]],
  ["Your reputation is damaged by something you did not do.","Fight it","Ignore it","Prove the truth","Leave town",["RES","CHA"],[4,4]],
  ["A teacher offers you a difficult apprenticeship.","Accept","Decline","Ask for a trial","Choose a different teacher",["CON","AMB"],[4,4]],
  ["You can gain power at the cost of freedom.","Accept","Refuse","Accept temporarily","Find another route",["IND","RISK"],[5,4]],
  ["You discover an old civilization under the frontier.","Explore","Report it","Keep it secret","Study it first",["PER","CRE"],[5,4]],
  ["A friend asks you to keep a dangerous secret.","Promise","Refuse","Keep it but seek help","Ask for the full story",["LOY","TRU"],[4,4]],
  ["You are outnumbered.","Fight","Escape","Negotiate","Create a distraction",["RISK","CRE"],[4,4]],
  ["A valuable invention could change the economy.","Publish","Keep private","License it","Give it away",["CRE","UTIL"],[5,3]],
  ["A political faction offers you status.","Accept","Refuse","Accept only if useful","Remain independent",["DOM","IND"],[4,4]],
  ["Your mentor asks you to surpass them.","Accept the challenge","Refuse","Learn first","Find your own path",["AMB","ADP"],[5,4]],
  ["You can save one important item during an evacuation.","Weapon","Book","Keepsake","Tool",["UTIL","COMP"],[3,4]],
  ["A rival proposes cooperation.","Accept","Refuse","Trial partnership","Set strict terms",["ADP","TRU"],[4,4]],
  ["You have to speak before a hostile crowd.","Be forceful","Be honest","Use humor","Stay silent",["CHA","RES"],[5,3]],
  ["A new culture has rules you dislike.","Adapt","Refuse","Ask why","Follow until you understand",["ADP","PER"],[5,4]],
  ["You discover your friend lied to protect you.","Thank them","Confront them","Set a boundary","Forgive",["TRU","LOY"],[4,4]],
  ["You can become a specialist or a generalist.","Specialist","Generalist","Hybrid","Depends on opportunities",["CON","ADP"],[4,4]],
  ["A disaster destroys your original plan.","Start again","Change goals","Find a new team","Wait",["RES","ADP"],[5,4]],
  ["You are offered a chance to teach others.","Accept","Decline","Teach part-time","Create a school",["SOC","AMB"],[4,5]],
  ["Someone claims your success was luck.","Ignore","Prove them wrong","Explain your work","Agree that luck mattered",["RES","HON"],[3,3]],
  ["You have evidence of corruption.","Expose it","Sell it","Investigate more","Give it to a trusted ally",["JUST","PER"],[5,4]],
  ["A dangerous creature appears but is not attacking.","Observe","Attack","Leave","Try communication",["PER","COMP"],[5,4]],
  ["You are asked to judge a friend fairly.","Protect them","Judge fairly","Recuse yourself","Ask for evidence",["HON","JUST"],[5,4]],
  ["Your resources are running low.","Work","Trade","Explore","Reduce spending",["UTIL","CON"],[4,4]],
  ["A stranger offers you a map to somewhere legendary.","Go","Sell it","Study it","Find a guide",["RISK","PER"],[4,4]],
  ["You have a chance to rewrite one mistake.","Do it","Accept it","Learn from it","Help someone else avoid it",["RES","COMP"],[4,4]],
  ["A close friend wants a different life from you.","Follow them","Support them","Convince them","Let them go",["LOY","IND"],[4,4]],
  ["You inherit an organization you did not ask for.","Accept","Dissolve it","Reform it","Delegate",["DOM","CON"],[5,4]],
  ["Your society values status more than skill.","Play the game","Reject it","Use status strategically","Build a new path",["UTIL","IND"],[5,4]],
  ["You find a forbidden text.","Read","Destroy","Seal it","Study safely",["CRE","RISK"],[4,4]],
  ["Your health limits your old fighting style.","Adapt","Quit","Find a new technique","Ask for treatment",["ADP","RES"],[5,4]],
  ["A prophecy predicts a future you dislike.","Accept","Resist","Investigate","Ignore",["ADP","AMB"],[4,4]],
  ["Your group has no supplies after a journey.","Hunt","Trade","Return","Invent a solution",["SELF","CRE"],[4,5]],
  ["A peaceful job is available, but adventure is calling.","Peace","Adventure","Try both","Choose based on people",["SELF","RISK"],[4,4]],
  ["You learn that your greatest rival is protecting someone you care about.","Cooperate","Distrust","Ask why","Walk away",["ADP","COMP"],[5,4]],
  ["A student surpasses you.","Celebrate","Train harder","Teach them more","Feel threatened",["COMP","AMB"],[5,3]],
  ["A leader asks you to take responsibility for a failure.","Accept","Refuse","Share responsibility","Investigate",["HON","RES"],[5,4]],
  ["A mysterious organization offers answers about your arrival.","Join","Observe","Refuse","Infiltrate",["PER","RISK"],[4,4]],
  ["You can choose comfort or a difficult path with greater impact.","Comfort","Impact","Balance","Ask who benefits",["AMB","COMP"],[4,4]],
  ["Your community asks what legacy you want.","Family","Knowledge","Power","Peace",["COMP","AMB"],[4,4]],
];

const makeQuestions = () => QUESTIONS.map((q,i)=>({
  id:"q"+(i+1), text:q[0], choices:q.slice(1,5).map((label,j)=>({label,d:{[q[5][j%q[5].length]]:q[6][j%q[6].length], [q[5][(j+1)%q[5].length]]:Math.max(1,q[6][j%q[6].length]-1)}}))
}));

function initialTraits(){
  return Object.fromEntries(TRAITS.map(k=>[k,50]));
}

function scoreRole(traits, world, weapon){
  const scores = ROLES.map(r=>{
    let s = 0;
    const n = r.name.toLowerCase();
    if(n.includes("mage")||n.includes("priest")||n.includes("oracle")||n.includes("psychic")) s += traits.INT*0.5+traits.CRE*0.3;
    if(n.includes("fighter")||n.includes("warrior")||n.includes("knight")||n.includes("berserker")||n.includes("brawler")) s += traits.RISK*.3+traits.RES*.4+traits.DOM*.2;
    if(n.includes("assassin")||n.includes("spy")||n.includes("scout")||n.includes("detective")) s += traits.PER*.4+traits.IND*.25+traits.LOG*.2;
    if(n.includes("leader")||n.includes("commander")||n.includes("general")||n.includes("king")||n.includes("guildmaster")) s += traits.DOM*.4+traits.CHA*.25+traits.CON*.2;
    if(n.includes("engineer")||n.includes("scientist")||n.includes("programmer")||n.includes("inventor")) s += traits.INT*.45+traits.CRE*.35+traits.LOG*.2;
    if(n.includes("healer")||n.includes("medic")||n.includes("physician")||n.includes("priest")||n.includes("saint")) s += traits.COMP*.35+traits.INT*.25+traits.CON*.2;
    if(n.includes("merchant")||n.includes("diplomat")||n.includes("politician")) s += traits.SOC*.3+traits.UTIL*.3+traits.CHA*.25;
    if(n.includes("survivor")||n.includes("scavenger")||n.includes("nomad")||n.includes("explorer")) s += traits.ADP*.35+traits.SELF*.3+traits.PER*.2;
    if(n.includes("martial")||n.includes("cultivator")||n.includes("qi")||n.includes("sect")) s += traits.CON*.3+traits.RES*.35+traits.AMB*.2;
    if(world==="wildwest" && ["gunslinger","cowboy","sheriff","outlaw","drifter","prospector"].some(x=>n.includes(x))) s+=35;
    if(world==="murim" && ["martial","cultivator","qi","sect","spear disciple","sword disciple"].some(x=>n.includes(x))) s+=35;
    if(world==="apocalypse" && ["survivor","scavenger","engineer","medic","mechanic","scientist"].some(x=>n.includes(x))) s+=35;
    if(world==="academia" && ["scholar","researcher","scientist","mage","historian","philosopher"].some(x=>n.includes(x))) s+=25;
    if(weapon==="gun" && n.includes("gun")) s+=25;
    if(weapon==="spear" && n.includes("spear")) s+=25;
    if(weapon==="sword" && n.includes("sword")) s+=25;
    return {...r,score:s+Math.random()*15};
  }).sort((a,b)=>b.score-a.score);
  return scores[0];
}

function buildGoals(traits, world){
  const pool = [
    ["Become the strongest version of yourself", traits.AMB+traits.RES],
    ["Protect the people who matter to you", traits.LOY+traits.COMP],
    ["Understand the world completely", traits.INT+traits.PER],
    ["Build something that outlives you", traits.CRE+traits.AMB],
    ["Live freely without being controlled", traits.IND+traits.RISK],
    ["Change an unjust system", traits.JUST+traits.AMB],
    ["Create a peaceful life", traits.SELF+traits.CON],
    ["Master a chosen discipline", traits.CON+traits.AMB],
    ["Become wealthy and independent", traits.UTIL+traits.AMB],
    ["Discover the truth behind your arrival", traits.PER+traits.INT]
  ];
  const sorted=[...pool].sort((a,b)=>b[1]-a[1]);
  const main=sorted[0][0];
  const objectives=sorted.slice(0,5).map((x,i)=>[
    `Milestone ${i+1}: ${x[0]}`,
    i===0?"Find the first person or opportunity connected to this goal.":i===1?"Survive the first major setback.":i===2?"Gain the skill, resource or status needed to continue.":i===3?"Make a choice that permanently changes your direction.":"Reach a point where the goal changes the world around you."
  ]);
  return {potential:pool.map(x=>x[0]),main,objectives};
}

function generateCharacter(traits, worldId, gender, name, companion){
  const weapon = pick(WEAPONS);
  const role = scoreRole(traits,worldId,weapon.id);
  const goals=buildGoals(traits,worldId);
  const affinities={};
  WEAPONS.forEach(w=>affinities[w.id]=clamp(35+traits.ADP*.25+traits.CRE*.15+(w.id===weapon.id?20:0)+Math.random()*20));
  const mental={
    hope:clamp(traits.RES*.65+traits.COMP*.15),
    despair:clamp(100-traits.RES*.7),
    hatred:clamp(50+traits.JUST*.1-traits.COMP*.1),
    acceptance:clamp(traits.RES*.4+traits.ADP*.4),
    obsession:clamp(traits.AMB*.7),
    fear:clamp(100-traits.RISK*.6),
    apathy:clamp(100-traits.COMP*.6),
  };
  return {
    id:uid(),name,gender,world:worldId,age:17,race:"Human",role,weapon,
    traits,affinities,goals,companion,mental,
    health:"Healthy",wealth:25,reputation:10,location:"Starting Settlement",
    title:"New Soul",relationships:{trust:45,friendship:25,respect:20,conflict:5},
    inventory:[weapon.name,"Old keepsake","Basic supplies"],history:[],year:1,alive:true
  };
}

function applyDelta(traits,d){
  const next={...traits};
  Object.entries(d).forEach(([k,v])=>next[k]=clamp((next[k]??50)+v));
  return next;
}

function chooseCompanion(prayer){
  const pool = [
    {name:"Dodo",age:17,role:"Working companion",reliability:62,loyalty:82,mental:55,style:"Energetic, absurd, temperamental, helpful."},
    {name:"Dio",age:17,role:"Student / strategist",reliability:78,loyalty:71,mental:72,style:"Mature, logical, pragmatic, self-sacrificing."},
    {name:"Niggel",age:18,role:"Foreign scholar",reliability:91,loyalty:86,mental:78,style:"Quiet, diligent, smart, culturally different."},
    {name:"Zen",age:17,role:"Gamer / adventurer",reliability:54,loyalty:81,mental:43,style:"Brave, impulsive, funny, sometimes unreliable."},
    {name:"Parel",age:16,role:"Ordinary friend",reliability:48,loyalty:74,mental:58,style:"Directable, loyal, regular guy."},
    {name:"Padil",age:16,role:"Young companion",reliability:55,loyalty:88,mental:46,style:"Self-sacrificing, loyal, emotionally variable."},
    {name:"Ajiz",age:17,role:"Adrenaline seeker",reliability:49,loyalty:61,mental:51,style:"Confident, reckless, surprisingly thoughtful."},
    {name:"Bayu",age:24,role:"Worker / mentor-like friend",reliability:92,loyalty:84,mental:86,style:"Mature, calm, thoughtful, good listener."},
    {name:"Ebo",age:23,role:"Protector",reliability:89,loyalty:85,mental:81,style:"Caring, practical, safety-oriented."},
    {name:"Jacky",age:17,role:"Rival-friend",reliability:67,loyalty:79,mental:68,style:"Proud, brave, joking, caring beneath the pride."},
    {name:"Arden",age:25,role:"Engineer",reliability:88,loyalty:65,mental:79,style:"Logical, mature, inventive, revolutionary."},
    {name:"Lala",age:25,role:"Merchant",reliability:80,loyalty:83,mental:82,style:"Energetic, kind, wealthy, loyal."},
    {name:"Jakkeh",age:20,role:"Wandering socialite",reliability:59,loyalty:69,mental:64,style:"YOLO, random, peaceful, socially skilled."},
  ];
  const p=(prayer||"surprise").toLowerCase();
  let scored=pool.map(x=>{
    let s=Math.random()*35;
    if(p.includes("trust")||p.includes("reliable"))s+=x.reliability;
    if(p.includes("strong"))s+=x.loyalty*.4;
    if(p.includes("smart")||p.includes("understand"))s+=x.reliability*.5;
    if(p.includes("funny"))s+=x.mental*.2;
    return {...x,score:s};
  }).sort((a,b)=>b.score-a.score);
  return scored[0];
}

function randomEvent(world,traits){
  const major=Math.random()<.28;
  const source=major?pick(MAJOR_EVENTS):pick(SECONDARY_EVENTS);
  return {...source,major};
}

function eventChoice(event, index){
  const sets=[
    ["Act immediately","Gather information","Ask your companion","Wait and observe"],
    ["Take the risk","Find a safer route","Negotiate","Turn it into an opportunity"],
    ["Protect people first","Protect resources first","Protect your goal","Protect yourself"],
    ["Be honest","Be strategic","Stay silent","Ask for help"]
  ];
  return sets[index%sets.length];
}

function narrativeFor(char,event,choice){
  const name=char.name, comp=char.companion?.name||"your companion";
  return `${name} chose to ${choice.toLowerCase()} when ${event.name.toLowerCase()} ${event.major?"became a turning point":"interrupted ordinary life"}. ${comp} became part of the decision, and the result shifted the next stage of the journey.`;
}

function App(){
  const [screen,setScreen]=useState("landing");
  const [name,setName]=useState("");
  const [gender,setGender]=useState("Male");
  const [prayer,setPrayer]=useState("");
  const [gacha,setGacha]=useState(null);
  const [world,setWorld]=useState(null);
  const [qIndex,setQIndex]=useState(0);
  const [traits,setTraits]=useState(initialTraits());
  const [answers,setAnswers]=useState([]);
  const [secondaryIndex,setSecondaryIndex]=useState(0);
  const [secondaryAnswers,setSecondaryAnswers]=useState([]);
  const [char,setChar]=useState(null);
  const [tab,setTab]=useState("home");
  const [currentEvent,setCurrentEvent]=useState(null);
  const [eventLog,setEventLog]=useState([]);
  const [historyOpen,setHistoryOpen]=useState(null);
  const [ending,setEnding]=useState(null);

  const questionPool=useMemo(()=>QUESTIONS.map((q,i)=>({
    id:"q"+(i+1),text:q[0],
    choices:q.slice(1,5).map((label,j)=>({label,d:{
      [q[5][j%q[5].length]]:q[6][j%q[6].length],
      [q[5][(j+1)%q[5].length]]:Math.max(1,q[6][j%q[6].length]-1)
    }}))
  })),[]);

  const secondaryPool=useMemo(()=>questionPool.slice(0,25).map((q,i)=>({
    ...q,id:"s"+(i+1),
    text:["Now that you know your world, "+q.text.toLowerCase(),"Your companion asks: "+q.text.toLowerCase(),"A year has passed. "+q.text.toLowerCase()][i%3]
  })),[questionPool]);

  function start(){
    setName("");setScreen("name");
  }
  function submitName(){
    const n=name.trim()||"Nameless";
    setName(n);setScreen("goddess");
  }
  function doPrayer(){
    const c=chooseCompanion(prayer);
    setGacha(c);setScreen("rolling");
    setTimeout(()=>setScreen("world"),850);
  }
  function answerPrimary(choice){
    setTraits(t=>applyDelta(t,choice.d));
    setAnswers(a=>[...a,{q:qIndex,choice:choice.label}]);
    if(qIndex+1<questionPool.length)setQIndex(i=>i+1);
    else {setSecondaryIndex(0);setScreen("secondary");}
  }
  function answerSecondary(choice){
    setTraits(t=>applyDelta(t,choice.d));
    setSecondaryAnswers(a=>[...a,{q:secondaryIndex,choice:choice.label}]);
    if(secondaryIndex+1<secondaryPool.length)setSecondaryIndex(i=>i+1);
    else {
      const c=generateCharacter(traits,world.id,gender,name,gacha);
      c.traits=applyDelta(traits,choice.d);
      c.goals=buildGoals(c.traits,world.id);
      setChar(c);setScreen("sheet");
    }
  }
  function beginLife(){
    setTab("home");setScreen("lobby");
    setCurrentEvent(randomEvent(char.world,char.traits));
  }
  function nextEvent(choiceIndex){
    if(!currentEvent)return;
    const choices=eventChoice(currentEvent,0);
    const choice=choices[choiceIndex];
    const d=[
      {RISK:2,RES:1},{PER:2,INT:1},{COMP:2,LOY:1},{CON:2,SELF:1}
    ][choiceIndex];
    const nextChar={...char,age:char.age+1,year:char.year+1,traits:applyDelta(char.traits,d),
      reputation:clamp(char.reputation+(choiceIndex===0?3:1)),wealth:Math.max(0,char.wealth+(choiceIndex===1?8:-2)),
      mental:{...char.mental,hope:clamp(char.mental.hope+(choiceIndex===2?4:1)),acceptance:clamp(char.mental.acceptance+1)}};
    const log={id:uid(),year:nextChar.year,age:nextChar.age,event:currentEvent.name,choice,narrative:narrativeFor(char,currentEvent,choice),
      mental:{...nextChar.mental},traits:{...nextChar.traits},major:currentEvent.major};
    nextChar.history=[...char.history,log];
    if(nextChar.age>=80){nextChar.alive=false;setChar(nextChar);setEnding(makeEnding(nextChar));setScreen("ending");return;}
    setChar(nextChar);setEventLog(l=>[...l,log]);setCurrentEvent(randomEvent(nextChar.world,nextChar.traits));
  }
  function makeEnding(c){
    const top=Object.entries(c.traits).sort((a,b)=>b[1]-a[1]).slice(0,3).map(x=>TRAIT_LABEL[x[0]]).join(", ");
    return {
      title:`${c.role.name} — ${c.title}`,
      age:c.age,
      summary:`${c.name} lived a life shaped by ${top}. The path was not predetermined; repeated choices changed relationships, skills, opportunities and worldview.`,
      legacy:[`Known as ${c.role.name}.`,`Main goal: ${c.goals.main}.`,`Companion bond: ${c.companion?.name||"none"}.`,`Final reputation: ${c.reputation}.`,`Final wealth: ${c.wealth}.`]
    };
  }
  function reset(){location.reload();}

  const worldObj=WORLDS.find(w=>w.id===char?.world)||world;

  return <div className="app">
    <header className="top"><div className="brand">SECOND LIFE</div><div className="sub">Fantasy Life Simulator</div></header>

    {screen==="landing"&&<main className="center hero">
      <div className="orb">✦</div><h1>Your second life begins<br/>with a decision.</h1>
      <p>A state-driven fantasy life simulator: world, personality, class, relationships, goals, mental state, events and legacy evolve together.</p>
      <button className="primary" onClick={start}>BEGIN SECOND LIFE</button>
      <small>Psychologically inspired game system — not a clinical or validated assessment.</small>
    </main>}

    {screen==="name"&&<main className="panel">
      <h2>Before rebirth</h2><p>What should this life call you?</p>
      <input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name"/>
      <label>Gender</label><select value={gender} onChange={e=>setGender(e.target.value)}>{GENDERS.map(g=><option key={g}>{g}</option>)}</select>
      <button className="primary" onClick={submitName}>CONTINUE</button>
    </main>}

    {screen==="goddess"&&<main className="panel goddess">
      <div className="orb">☽</div><h2>The Goddess</h2><p>“You have been given one more life. What do you want from it?”</p>
      <div className="grid2">
        {["Strength","Peace","A companion","Knowledge","Justice","Freedom","I don't know"].map(x=><button key={x} onClick={()=>{setPrayer(x);setScreen("prayer")}}>{x}</button>)}
      </div>
    </main>}

    {screen==="prayer"&&<main className="panel">
      <h2>Prayer / Gacha</h2><p>You may ask for a kind of person. The prayer changes the probability pool; it does not guarantee a specific soul.</p>
      <div className="grid2">
        {["Someone I can trust","Someone strong","Someone smart","Someone funny","Someone who understands me","Someone loyal","Someone random","I want to be alone"].map(x=>
          <button key={x} onClick={()=>{setPrayer(x);doPrayer()}}>{x}</button>)}
      </div>
    </main>}

    {screen==="rolling"&&<main className="center"><div className="gacha">1... ✨<br/>2... ✨✨<br/>3... ✨✨✨</div><h2>The Goddess heard your prayer.</h2><p>A soul is being summoned...</p></main>}

    {screen==="world"&&<main className="panel wide">
      <h2>Choose your world</h2><p>Your world is a ruleset, not a cosmetic skin. It changes technology, power systems, society, economy and available roles.</p>
      <div className="worldGrid">{WORLDS.map(w=><button className="worldCard" key={w.id} onClick={()=>{setWorld(w);setQIndex(0);setScreen("assessment")}}>
        <b>{w.name}</b><span>{w.tag}</span><p>{w.desc}</p><small>{w.systems.join(" • ")}</small>
      </button>)}</div>
    </main>}

    {screen==="assessment"&&<main className="panel">
      <div className="progress">World Assessment · {qIndex+1}/{questionPool.length}</div>
      <h2>{questionPool[qIndex].text}</h2>
      <div className="answers">{questionPool[qIndex].choices.map((c,i)=><button key={i} onClick={()=>answerPrimary(c)}>{c.label}</button>)}</div>
      <small>Choices influence multiple hidden traits. Some questions overlap to test consistency.</small>
    </main>}

    {screen==="secondary"&&<main className="panel">
      <div className="progress">Secondary Assessment · {secondaryIndex+1}/{secondaryPool.length}</div>
      <h2>{secondaryPool[secondaryIndex].text}</h2>
      <div className="answers">{secondaryPool[secondaryIndex].choices.map((c,i)=><button key={i} onClick={()=>answerSecondary(c)}>{c.label}</button>)}</div>
      <small>This stage is contextualized by the world and your first assessment.</small>
    </main>}

    {screen==="sheet"&&char&&<CharacterSheet char={char} world={worldObj} onContinue={beginLife} onHistory={()=>{setScreen("history");setHistoryOpen(null)}}/>}

    {screen==="lobby"&&char&&<main className="panel wide">
      <div className="lobbyHead"><div><span className="eyebrow">YEAR {char.year} · AGE {char.age}</span><h2>{char.name}</h2><p>{char.role.name} · {worldObj.name}</p></div><button onClick={()=>setScreen("history")}>📖 LIFE HISTORY</button></div>
      <nav className="tabs">{["home","character","people","goals","inventory"].map(t=><button className={tab===t?"active":""} onClick={()=>setTab(t)} key={t}>{t}</button>)}</nav>
      {tab==="home"&&<div className="dashboard">
        <section className="eventBox"><div className="eyebrow">{currentEvent?.major?"MAJOR EVENT":"LIFE EVENT"}</div><h2>{currentEvent?.name}</h2><p>Another year of your life is unfolding. Your previous choices affect what becomes possible next.</p>
          <div className="answers">{eventChoice(currentEvent,0).map((x,i)=><button key={x} onClick={()=>nextEvent(i)}>{x}</button>)}</div>
        </section>
        <div className="stats"><Stat label="Health" value={char.health}/><Stat label="Reputation" value={char.reputation}/><Stat label="Wealth" value={char.wealth}/><Stat label="Hope" value={char.mental.hope}/><Stat label="Despair" value={char.mental.despair}/><Stat label="Acceptance" value={char.mental.acceptance}/></div>
      </div>}
      {tab==="character"&&<CharacterMini char={char}/>}
      {tab==="people"&&<People char={char}/>}
      {tab==="goals"&&<Goals char={char}/>}
      {tab==="inventory"&&<Inventory char={char}/>}
    </main>}

    {screen==="history"&&char&&<History char={char} open={historyOpen} setOpen={setHistoryOpen} onBack={()=>setScreen("lobby")}/>}
    {screen==="ending"&&ending&&<main className="panel center"><div className="orb">✦</div><div className="eyebrow">THE END</div><h1>{ending.title}</h1><p>{ending.summary}</p><div className="card">{ending.legacy.map((x,i)=><p key={i}>• {x}</p>)}</div><button className="primary" onClick={reset}>LIVE AGAIN</button></main>}
  </div>
}

function Stat({label,value}){return <div className="stat"><span>{label}</span><b>{typeof value==="number"?value:value}</b></div>}
function CharacterSheet({char,world,onContinue,onHistory}){
 return <main className="panel wide">
  <div className="sheetHero"><div className="orb small">✦</div><div><div className="eyebrow">CHARACTER SHEET</div><h1>{char.name}</h1><p>{char.age} · {char.gender} · {char.race} · {world.name}</p></div></div>
  <div className="sheetGrid">
   <section className="card"><h3>Class</h3><p className="big">{char.role.name}</p><p>{char.role.tier} tier · inferred from traits, world, weapon and choices.</p><h3>Weapon</h3><p className="big">{char.weapon.name}</p><p>{char.weapon.desc}</p></section>
   <section className="card"><h3>Goals</h3><p><b>Main:</b> {char.goals.main}</p><p><b>Objectives:</b></p><ol>{char.goals.objectives.map(x=><li key={x[0]}>{x[0]}</li>)}</ol></section>
   <section className="card"><h3>Traits</h3><div className="traitList">{Object.entries(char.traits).map(([k,v])=><div key={k}><span>{TRAIT_LABEL[k]}</span><i><em style={{width:v+"%"}}/></i><b>{v}</b></div>)}</div></section>
   <section className="card"><h3>Mental State</h3><div className="miniStats">{Object.entries(char.mental).map(([k,v])=><Stat key={k} label={k} value={v}/>)}</div></section>
  </div>
  <div className="actionRow"><button onClick={onHistory}>📖 VIEW LIFE HISTORY</button><button className="primary" onClick={onContinue}>▶ CONTINUE → LOBBY</button></div>
 </main>
}
function CharacterMini({char}){return <div className="sheetGrid"><section className="card"><h3>{char.role.name}</h3><p>{char.role.tier} · {char.weapon.name}</p></section><section className="card"><h3>Worldview</h3><p>{char.mental.acceptance>70?"You increasingly accept uncertainty.":char.mental.hope>70?"You believe the future can still improve.":"You remain cautious about the future."}</p></section><section className="card"><h3>Core traits</h3>{Object.entries(char.traits).sort((a,b)=>b[1]-a[1]).slice(0,7).map(([k,v])=><Stat key={k} label={TRAIT_LABEL[k]} value={v}/>)}</section></div>}
function People({char}){return <div className="card"><h2>{char.companion?.name}</h2><p>{char.companion?.style}</p><div className="miniStats"><Stat label="Reliability" value={char.companion?.reliability}/><Stat label="Loyalty" value={char.companion?.loyalty}/><Stat label="Mental resilience" value={char.companion?.mental}/><Stat label="Relationship trust" value={char.relationships.trust}/></div><p className="muted">Relationship can evolve through repeated events rather than being locked to the summon.</p></div>}
function Goals({char}){return <div className="card"><h2>Main Goal</h2><p className="big">{char.goals.main}</p><h3>5 Main Objectives</h3><ol>{char.goals.objectives.map(x=><li key={x[0]}><b>{x[0]}</b><br/><span>{x[1]}</span></li>)}</ol><h3>Potential Goals</h3><div className="chips">{char.goals.potential.map(x=><span key={x}>{x}</span>)}</div></div>}
function Inventory({char}){return <div className="card"><h2>Inventory</h2>{char.inventory.map((x,i)=><div className="inventory" key={i}>◇ {x}</div>)}</div>}
function History({char,open,setOpen,onBack}){
 return <main className="panel wide"><div className="lobbyHead"><div><div className="eyebrow">LIFE HISTORY</div><h1>{char.name}</h1><p>A year-by-year record of events, development, relationships, mental state and worldview.</p></div><button onClick={onBack}>← LOBBY</button></div>
 <div className="history">
  <div className="timeline">{char.history.length===0?<div className="card"><h2>The first chapter is waiting.</h2><p>Return to the lobby and make decisions. Each completed year will appear here.</p></div>:char.history.map((h,i)=><button className={"year "+(open===i?"selected":"")} key={h.id} onClick={()=>setOpen(i)}><b>Year {h.year}</b><span>Age {h.age}</span><small>{h.major?"Major event":"Life event"}</small></button>)}</div>
  <article className="historyArticle">{open===null?<div className="card"><h2>Biography</h2><p>{char.name} began this life at age 17 in {WORLDS.find(w=>w.id===char.world)?.name}. Their path is generated from world rules, hidden traits, goals, relationships and decisions.</p><h3>Current worldview</h3><p>{char.mental.acceptance>70?"They have learned to live with uncertainty.":char.mental.despair>60?"The world has made them deeply cautious.":"They continue to negotiate between hope and caution."}</p></div>:<div className="card">{(()=>{const h=char.history[open];return <><div className="eyebrow">YEAR {h.year} · AGE {h.age}</div><h2>{h.event}</h2><p>{h.narrative}</p><h3>Choice</h3><p>{h.choice}</p><h3>Mental state</h3><div className="miniStats">{Object.entries(h.mental).map(([k,v])=><Stat key={k} label={k} value={v}/>)}</div><h3>What changed</h3><p>Your decision changed the state of the character. Later events can reference this history.</p></>})()}</div>}</article>
 </div>
 </main>
}

