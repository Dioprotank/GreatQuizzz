# Second Life — Fantasy Life Simulator

Runnable React/Vite prototype.

## Run
```bash
npm install
npm run dev
```

Then open the local Vite address.

## Included
- Full flow: Death/name -> Goddess -> prayer/gacha -> world -> 75-question world assessment -> 25-question secondary assessment -> goals -> character sheet -> lobby.
- 12 world rulesets, including exactly one Murim and one Wild West.
- 7 gender options.
- 25 weapons.
- 150+ role/class database with tier tags and inferred role selection.
- 175 chat/relationship text variations.
- 25 major + 25 secondary event definitions.
- 10 potential goals + 1 main goal + 5 objectives.
- Companion summon pool and relationship stats.
- Trait engine, affinity, mental state, year-by-year history, worldview, inventory, wealth, reputation and ending.
- State-driven events with persistent history rather than isolated text branches.

The assessment is psychologically inspired game logic, not a validated psychological, IQ, MBTI, or clinical test.
